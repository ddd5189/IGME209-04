#include "pch.h"
#include "Orc.h"


Orc::Orc()
{
}


Orc::~Orc()
{
}

// orc specif display
void Orc::Display()
{
	cout << "Orc " << "x:" << xPosition << " y:" << yPosition << endl;
}
